# NAJIYA ROYAL TENT HOUSE — Complete Project

## शामिल फीचर
- Premium navy/gold responsive website
- Home, services, contact, call, WhatsApp message और SMS
- Online booking form, booking ID, 20% advance calculation
- Home service booking option
- Booking status lookup और cancellation request
- Customer register/login, customer booking lookup
- Razorpay India order creation और payment signature verification
- Admin login/dashboard, booking status update
- Inventory/stock, expenses, staff records
- Basic income/expense summary
- Print receipt; browser print में Save as PDF

## चलाने के लिए
1. ZIP extract करें।
2. Node.js 20+ वाले computer या Replit/Node hosting में project खोलें।
3. `npm install` चलाएँ।
4. `.env.example` की copy बनाकर `.env` नाम दें।
5. `.env` में मजबूत `JWT_SECRET`, `ADMIN_PASSWORD`, अपना admin mobile और Razorpay keys डालें।
6. `npm start` चलाएँ और `http://localhost:3000` खोलें।

## Admin
Default admin mobile `.env.example` में 7043551103 है। अपना मजबूत password `.env` में सेट करें। पहली बार server चलने पर admin account बनता है। यदि पहले से database बना हो तो admin password बदलने के लिए अलग सुरक्षित reset प्रक्रिया चाहिए।

## Payment
Razorpay account और KYC/activation जरूरी है। पहले Test Mode keys लगाकर जाँचें। `RAZORPAY_KEY_ID` और `RAZORPAY_KEY_SECRET` केवल server `.env` में रखें। खाली keys पर online payment उपलब्ध नहीं होगा।

## ध्यान दें
यह production-ready starter है, पूर्ण ERP/accounting या कानूनी tax system नहीं। Income summary फिलहाल जमा advance को revenue मानती है। Admin panel में booking status, stock, expenses और staff manage कर सकते हैं। SQLite database `najiya.sqlite` में रहता है; hosting पर persistent disk और नियमित backup जरूरी है। GitHub Pages पर backend नहीं चलेगा; Node.js hosting चाहिए। HTTPS लगाएँ और deployment से पहले credentials बदलें।
