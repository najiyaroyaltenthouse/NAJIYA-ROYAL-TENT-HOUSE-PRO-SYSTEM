require("dotenv").config();

const express = require("express");
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const path = require("path");

const app = express();
const db = new Database("najiya.sqlite");

app.use(helmet());
app.use(express.json());
app.use(cookieParser());
app.use(express.static("public"));

db.exec(`
CREATE TABLE IF NOT EXISTS bookings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT,
 phone TEXT,
 category TEXT,
 event_date TEXT,
 address TEXT,
 items TEXT,
 total INTEGER,
 advance INTEGER,
 status TEXT DEFAULT 'Pending'
);

CREATE TABLE IF NOT EXISTS reviews (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT,
 rating INTEGER,
 message TEXT
);

CREATE TABLE IF NOT EXISTS expenses (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT,
 amount INTEGER,
 date TEXT
);

CREATE TABLE IF NOT EXISTS inventory (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 item TEXT,
 quantity INTEGER
);

CREATE TABLE IF NOT EXISTS coupons (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 code TEXT UNIQUE,
 discount INTEGER
);
`);

const SECRET = process.env.JWT_SECRET || "change-this-secret";

function adminAuth(req,res,next) {
 try {
  const token = req.cookies.admin;
  if(!token) return res.status(401).json({error:"Login required"});
  jwt.verify(token,SECRET);
  next();
 } catch {
  res.status(401).json({error:"Invalid session"});
 }
}

app.get("/api/config",(req,res)=>{
 res.json({
  name:"NAJIYA ROYAL TENT HOUSE",
  phone:"917043551103",
  owner:"NUREALAM"
 });
});

// CUSTOMER BOOKING
app.post("/api/bookings",(req,res)=>{
 const {
  name,phone,category,eventDate,address,items,total
 }=req.body;

 if(!name || !phone || !category || !eventDate || !address ||
 !items || !Number.isFinite(Number(total)) || Number(total)<1) {
  return res.status(400).json({error:"सभी जानकारी भरें"});
 }

 const amount=Number(total);
 const advance=Math.round(amount*0.20);

 const result=db.prepare(`
 INSERT INTO bookings
 (name,phone,category,event_date,address,items,total,advance)
 VALUES(?,?,?,?,?,?,?,?)
 `).run(name,phone,category,eventDate,address,items,amount,advance);

 res.json({
  success:true,
  bookingId:result.lastInsertRowid,
  total:amount,
  advance,
  balance:amount-advance,
  whatsapp:"https://wa.me/917043551103"
 });
});

// CUSTOMER BOOKING SEARCH
app.get("/api/bookings/:phone",(req,res)=>{
 const rows=db.prepare(
  "SELECT * FROM bookings WHERE phone=?"
 ).all(req.params.phone);

 res.json(rows);
});

// ADMIN LOGIN
app.post("/api/admin/login",async(req,res)=>{
 const {username,password}=req.body;

 if(username!==process.env.ADMIN_USERNAME ||
 password!==process.env.ADMIN_PASSWORD) {
  return res.status(401).json({error:"Wrong login"});
 }

 const token=jwt.sign({username},SECRET,{expiresIn:"8h"});

 res.cookie("admin",token,{
  httpOnly:true,
  sameSite:"strict",
  secure:process.env.NODE_ENV==="production"
 });

 res.json({success:true});
});

// ADMIN BOOKINGS
app.get("/api/admin/bookings",adminAuth,(req,res)=>{
 const rows=db.prepare(
  "SELECT * FROM bookings ORDER BY id DESC"
 ).all();

 res.json(rows);
});

// UPDATE BOOKING
app.patch("/api/admin/bookings/:id",adminAuth,(req,res)=>{
 db.prepare(
  "UPDATE bookings SET status=? WHERE id=?"
 ).run(req.body.status,req.params.id);

 res.json({success:true});
});

// COUPON
app.post("/api/admin/coupons",adminAuth,(req,res)=>{
 const {code,discount}=req.body;

 db.prepare(
  "INSERT INTO coupons(code,discount) VALUES(?,?)"
 ).run(code,Number(discount));

 res.json({success:true});
});

// REVIEWS
app.post("/api/reviews",(req,res)=>{
 const {name,rating,message}=req.body;

 db.prepare(
  "INSERT INTO reviews(name,rating,message) VALUES(?,?,?)"
 ).run(name,rating,message);

 res.json({success:true});
});

// INVENTORY
app.post("/api/admin/inventory",adminAuth,(req,res)=>{
 const {item,quantity}=req.body;

 db.prepare(
  "INSERT INTO inventory(item,quantity) VALUES(?,?)"
 ).run(item,quantity);

 res.json({success:true});
});

// EXPENSES
app.post("/api/admin/expenses",adminAuth,(req,res)=>{
 const {title,amount,date}=req.body;

 db.prepare(
  "INSERT INTO expenses(title,amount,date) VALUES(?,?,?)"
 ).run(title,amount,date);

 res.json({success:true});
});

app.get("/api/admin/inventory",adminAuth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM inventory").all());
});

app.get("/api/admin/expenses",adminAuth,(req,res)=>{
 res.json(db.prepare("SELECT * FROM expenses").all());
});

app.get("/health",(req,res)=>{
 res.json({status:"Website Running"});
});

app.listen(process.env.PORT || 3000,()=>{
 console.log("NAJIYA ROYAL TENT HOUSE Started");
});
