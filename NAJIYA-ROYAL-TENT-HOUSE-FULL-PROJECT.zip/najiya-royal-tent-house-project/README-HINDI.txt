NAJIYA ROYAL TENT HOUSE — PROJECT FILES

इस ZIP में:
- public/index.html : ग्राहक वेबसाइट + Booking + Track Booking + Reviews + Admin UI
- server.js : Node.js API / backend
- package.json : आवश्यक packages और start command
- .env.example : Hosting में भरने वाली environment settings का नमूना

महत्वपूर्ण:
1) ZIP को Extract करें।
2) इस प्रोजेक्ट को Node.js hosting पर deploy करें (Node.js 18+ और persistent disk जरूरी है)।
3) Hosting में package.json के अनुसार dependencies install होंगी और start command `npm start` होगी।
4) Hosting के Environment Variables में .env.example की values भरें। JWT_SECRET को लंबा और random रखें। ADMIN_USERNAME और ADMIN_PASSWORD अपने बनाएँ। असली password किसी को न भेजें।
5) BUSINESS_PHONE को country code सहित digits में रखें।
6) SQLite database file (najiya.sqlite) के लिए persistent disk/volume enable करें।

GitHub Pages केवल static HTML दिखाता है; वह server.js / SQLite backend नहीं चला सकता।
यदि GitHub Pages पर अलग से HTML डालेंगे तो /api endpoints उपलब्ध नहीं होंगे। Frontend को Node.js server की public/ directory से serve करना है, या API_BASE_URL configure करके frontend को backend host से जोड़ना होगा।
यह starter project है, payment gateway/online payment integration इसमें शामिल नहीं है। Advance केवल अनुमान के रूप में दिखता है; कोई पैसा collect नहीं होता।
पहले test deployment करें और production में इस्तेमाल से पहले hosting, backups, security और business details जाँचें।
