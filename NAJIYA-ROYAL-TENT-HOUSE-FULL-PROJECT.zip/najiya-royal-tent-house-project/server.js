require("dotenv").config();
const express = require("express");
const Database = require("better-sqlite3");
const cookieParser = require("cookie-parser");
const helmet = require("helmet");
const jwt = require("jsonwebtoken");
const path = require("path");

const app = express();
const db = new Database(process.env.DB_FILE || "najiya.sqlite");
const PORT = process.env.PORT || 3000;
const SECRET = process.env.JWT_SECRET;

if (!SECRET || SECRET.length < 32) {
  console.error("Set JWT_SECRET in .env (at least 32 characters).");
  process.exit(1);
}
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  console.error("Set ADMIN_USERNAME and ADMIN_PASSWORD in .env.");
  process.exit(1);
}

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "100kb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "public")));

db.exec(`
CREATE TABLE IF NOT EXISTS bookings (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, phone TEXT NOT NULL, category TEXT NOT NULL,
 event_date TEXT NOT NULL, address TEXT NOT NULL, items TEXT NOT NULL,
 total INTEGER NOT NULL, advance INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'Pending',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS reviews (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL, rating INTEGER NOT NULL, message TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS expenses (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL, amount INTEGER NOT NULL, date TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS inventory (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 item TEXT NOT NULL, quantity INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS coupons (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 code TEXT NOT NULL UNIQUE, discount INTEGER NOT NULL
);
`);

function adminAuth(req, res, next) {
  try {
    const token = req.cookies.admin;
    if (!token) return res.status(401).json({ error: "Please log in" });
    req.admin = jwt.verify(token, SECRET);
    next();
  } catch {
    res.status(401).json({ error: "Session expired. Please log in again." });
  }
}
const clean = v => String(v ?? "").trim();
const validPhone = v => /^[0-9+\-\s()]{7,20}$/.test(clean(v));

app.get("/api/config", (req, res) => res.json({
  name: process.env.BUSINESS_NAME || "NAJIYA ROYAL TENT HOUSE",
  phone: process.env.BUSINESS_PHONE || "917043551103",
  owner: process.env.BUSINESS_OWNER || "NUREALAM"
}));

app.post("/api/bookings", (req, res) => {
  const name = clean(req.body.name), phone = clean(req.body.phone);
  const category = clean(req.body.category), eventDate = clean(req.body.eventDate);
  const address = clean(req.body.address), items = clean(req.body.items);
  const total = Number(req.body.total);
  if (!name || !validPhone(phone) || !category || !eventDate || !address ||
      !items || !Number.isInteger(total) || total < 1 || total > 100000000) {
    return res.status(400).json({ error: "Please enter all booking details correctly." });
  }
  const advance = Math.round(total * 0.20);
  const result = db.prepare(`INSERT INTO bookings
    (name,phone,category,event_date,address,items,total,advance)
    VALUES(?,?,?,?,?,?,?,?)`).run(name, phone, category, eventDate, address, items, total, advance);
  res.json({ success: true, bookingId: result.lastInsertRowid, total, advance, balance: total - advance });
});

app.get("/api/bookings/:phone", (req, res) => {
  const phone = clean(req.params.phone);
  if (!validPhone(phone)) return res.status(400).json({ error: "Enter a valid phone number." });
  const rows = db.prepare(`SELECT id,category,event_date,total,advance,status,created_at
    FROM bookings WHERE phone=? ORDER BY id DESC`).all(phone);
  res.json(rows);
});

app.post("/api/admin/login", (req, res) => {
  if (clean(req.body.username) !== process.env.ADMIN_USERNAME ||
      clean(req.body.password) !== process.env.ADMIN_PASSWORD) {
    return res.status(401).json({ error: "Incorrect username or password." });
  }
  const token = jwt.sign({ username: process.env.ADMIN_USERNAME }, SECRET, { expiresIn: "8h" });
  res.cookie("admin", token, {
    httpOnly: true, sameSite: "strict",
    secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000
  });
  res.json({ success: true });
});
app.post("/api/admin/logout", adminAuth, (req, res) => {
  res.clearCookie("admin", { httpOnly: true, sameSite: "strict", secure: process.env.NODE_ENV === "production" });
  res.json({ success: true });
});
app.get("/api/admin/bookings", adminAuth, (req, res) => {
  res.json(db.prepare("SELECT * FROM bookings ORDER BY id DESC").all());
});
app.patch("/api/admin/bookings/:id", adminAuth, (req, res) => {
  const status = clean(req.body.status);
  if (!["Pending", "Accepted", "Rejected", "Completed"].includes(status))
    return res.status(400).json({ error: "Invalid booking status." });
  const result = db.prepare("UPDATE bookings SET status=? WHERE id=?").run(status, Number(req.params.id));
  if (!result.changes) return res.status(404).json({ error: "Booking not found." });
  res.json({ success: true });
});
app.get("/api/reviews", (req, res) => {
  res.json(db.prepare("SELECT name,rating,message,created_at FROM reviews ORDER BY id DESC LIMIT 30").all());
});
app.post("/api/reviews", (req, res) => {
  const name = clean(req.body.name), message = clean(req.body.message), rating = Number(req.body.rating);
  if (!name || !message || message.length > 1000 || !Number.isInteger(rating) || rating < 1 || rating > 5)
    return res.status(400).json({ error: "Enter your name, review and a 1–5 star rating." });
  db.prepare("INSERT INTO reviews(name,rating,message) VALUES(?,?,?)").run(name, rating, message);
  res.json({ success: true });
});
app.post("/api/admin/coupons", adminAuth, (req, res) => {
  const code = clean(req.body.code).toUpperCase(), discount = Number(req.body.discount);
  if (!/^[A-Z0-9_-]{3,24}$/.test(code) || !Number.isInteger(discount) || discount < 1 || discount > 90)
    return res.status(400).json({ error: "Coupon must be 3–24 characters; discount 1–90%." });
  try {
    db.prepare("INSERT INTO coupons(code,discount) VALUES(?,?)").run(code, discount);
    res.json({ success: true });
  } catch { res.status(409).json({ error: "That coupon code already exists." }); }
});
app.post("/api/coupons/validate", (req, res) => {
  const code = clean(req.body.code).toUpperCase();
  const row = db.prepare("SELECT discount FROM coupons WHERE code=?").get(code);
  if (!row) return res.status(404).json({ error: "Coupon not found." });
  res.json({ success: true, discount: row.discount });
});
app.post("/api/admin/inventory", adminAuth, (req, res) => {
  const item = clean(req.body.item), quantity = Number(req.body.quantity);
  if (!item || !Number.isInteger(quantity) || quantity < 0 || quantity > 1000000)
    return res.status(400).json({ error: "Enter an item and a valid quantity." });
  db.prepare("INSERT INTO inventory(item,quantity) VALUES(?,?)").run(item, quantity);
  res.json({ success: true });
});
app.get("/api/admin/inventory", adminAuth, (req, res) =>
  res.json(db.prepare("SELECT * FROM inventory ORDER BY item").all()));
app.post("/api/admin/expenses", adminAuth, (req, res) => {
  const title = clean(req.body.title), amount = Number(req.body.amount), date = clean(req.body.date);
  if (!title || !date || !Number.isInteger(amount) || amount < 1)
    return res.status(400).json({ error: "Enter expense title, amount and date." });
  db.prepare("INSERT INTO expenses(title,amount,date) VALUES(?,?,?)").run(title, amount, date);
  res.json({ success: true });
});
app.get("/api/admin/expenses", adminAuth, (req, res) =>
  res.json(db.prepare("SELECT * FROM expenses ORDER BY date DESC").all()));
app.get("/api/admin/summary", adminAuth, (req, res) => {
  const bookings = db.prepare("SELECT COUNT(*) AS count, COALESCE(SUM(total),0) AS sales FROM bookings").get();
  const expenses = db.prepare("SELECT COALESCE(SUM(amount),0) AS total FROM expenses").get();
  res.json({ bookings: bookings.count, bookingValue: bookings.sales, expenses: expenses.total,
    estimatedBalance: bookings.sales - expenses.total });
});
app.get("/health", (req, res) => res.json({ status: "Website Running" }));
app.listen(PORT, () => console.log(`NAJIYA ROYAL TENT HOUSE running on port ${PORT}`));
